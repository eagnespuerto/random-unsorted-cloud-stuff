# 2026 ED138: VISTA/VVV precovery (2010–2011): data and code

Companion archive to the note *Precovery of the Dwarf Planet Candidate 2026 ED138 in
2010–2011 VISTA/VVV Images* (E. A. Puerto, 2026).

## Result

15 positions of 2026 ED138 from VVV pawprint stacks on 2010-03-18 (J, H), 2010-03-25 (J),
2010-08-02 (Z, Y) and 2011-07-01 (Z, Y). Residuals from the JPL orbit: mean (−0.055″, +0.008″),
rms (0.060″, 0.021″) in (ΔRA·cos δ, ΔDec). Submitted to the Minor Planet Center on 2026-10-28
(code W91, submission ID `2026-10-28T16:38:07.859_0000CHyD`). At the time of writing the
submission has been received but the positions have not yet been accepted.

## Null results (also in the note)

| Archive | What was checked | Outcome |
|---|---|---|
| Catalina Sky Survey | CATCH (Mt. Lemmon, Mt. Bigelow, Bok NEO survey) | No frames: the object never rises above ~13° from Mt. Lemmon |
| ATLAS | 2666 frames via CATCH | Too shallow (median 5σ 18.5–18.8, object V ≈ 19.7) |
| SkyMapper DR4 | 41 frames; 8 usable 100 s frames measured | No detection: 5σ 17.3–18.5 in crowded fields, best S/N 2.7 at 1.7″ off |
| Gaia DR1/DR2/DR3 | Faint 2-parameter sources within 2″ of the track vs offset control tracks | No excess (622/608, 1416/1415, 1949/1911); a slow mover never gets merged into a source |
| VVV Ks | 135 pawprint stacks, 37 nights (2010–2014) | No reliable detections; S/N≥5 candidates lie 0.2–1.4″ off |
| VVV H, 2010-03-25 | 3 stacks | Excluded: bright-star halo shifts the centroid 0.2–0.3″ |

## Contents

- `mpc/ed138_W91_precovery_ades.psv`: the 15 positions in ADES PSV format, as submitted.
- `data/vvv_astrometry.csv`: all ZYJH measurements (18 rows; the 3 rows of 2010-03-25 H are excluded
  from the submission), with O−C, uncertainty and number of Gaia reference stars.
- `data/ks_results.csv`, `data/ks_astrometry.csv`, `data/ks_nights.txt`: the Ks search.
- `data/mpc_obs.csv`: one MPC position per night from MPEC 2026-U85 (DECam, Rubin), used in the figures.
- `data/ssois_2009-2016.tsv`: CADC SSOIS image list; `data/horizons_geocentric_2009-2026.txt`: JPL ephemeris.
- `figures/`: detection stamps (best per night and band, and all 15 frames), orbit/residual figure,
  SkyMapper stamps.
- `code/`: the Python scripts (forced photometry, Gaia track test, VVV astrometry, figures).
  They query JPL Horizons, the VISTA Science Archive and the Gaia archive at run time and were
  run from one working folder; paths are relative to it.
- `note/`: LaTeX source of the note.

## Method in brief

VSA DR5 1′ cutouts of VVV pawprint stacks; templates from other nights (object ≥30″ away)
resampled to the science grid, zero-point scaled and median-combined; 2-D Gaussian fit to the
subtracted image at the JPL prediction; local astrometric re-tie to Gaia DR3 (G 13–19, proper
motion applied); mid-times from detector time stamps.

## Use of AI tools

The archive searches, code, measurements, figures and text were produced with substantial help
from Claude (Anthropic; Claude Opus 5.5 via Claude Code), under the author's direction. The author
reviewed the results and is responsible for the content.

## Licence

Code: MIT. Data tables, figures and text: CC BY 4.0. VVV data: ESO programme 179.B-2002.

Author: Ella Agnes Puerto (ORCID 0009-0005-1624-2025), Independent Researcher, Manila, Philippines.
