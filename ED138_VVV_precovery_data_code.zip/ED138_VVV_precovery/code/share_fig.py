"""Share-quality precovery figures for 2026 ED138 in VVV.

usage: share_fig.py vvv OUT.png
       share_fig.py ks  OUT.png MIN_SNR [NMAX]
"""
import sys, csv, numpy as np
from astropy.time import Time
from astropy.wcs import WCS
from astropy.stats import sigma_clipped_stats
exec("\n".join(l for l in open("vvv_check.py").read().split("res, stamps = []")[0].split("\n")
               if not l.startswith("OUTDIR")))
mode, OUT = sys.argv[1], sys.argv[2]

if mode == "vvv":   # best stack per night/filter from the ZYJH run (2010-03-25 H excluded: blended)
    SEL = [("2010-03-18 09:03:34.1", "J", 251.025608, -45.488050, 11.1),
           ("2010-03-18 08:44:43.0", "H", 251.025644, -45.487962, 7.6),
           ("2010-03-25 07:21:28.9", "J", 250.991663, -45.539027, 8.4),
           ("2010-08-02 04:40:59.3", "Z", 248.377475, -45.320359, 21.6),
           ("2010-08-02 04:34:46.9", "Y", 248.377529, -45.320404, 11.7),
           ("2011-07-01 03:54:32.7", "Z", 250.567981, -45.569431, 30.5),
           ("2011-07-01 03:46:00.7", "Y", 250.568097, -45.569463, 24.0)]
else:
    MIN = float(sys.argv[3]); NMAX = int(sys.argv[4]) if len(sys.argv) > 4 else 8
    nights = {int(float(l.split()[0]) - 0.5): l.split() for l in open("ks_nights.txt")}
    best = {}
    for r in csv.DictReader(open("ks_results.csv")):
        n = int(float(r["mjd"]) - 0.5)
        if float(r["snr"]) >= MIN and (n not in best or float(r["snr"]) > float(best[n]["snr"])): best[n] = r
    pick = sorted(sorted(best.values(), key=lambda r: -float(r["snr"]))[:NMAX], key=lambda r: float(r["mjd"]))
    SEL = [(r["date"], "Ks", float(nights[int(float(r["mjd"])-0.5)][1]), float(nights[int(float(r["mjd"])-0.5)][2]),
            float(r["snr"])) for r in pick]

from scipy.ndimage import map_coordinates
def north_up(I, H, ra, dec, half=10.0):
    """Resample a 2*half arcsec stamp centred on (ra, dec): north up, east left."""
    n = int(2*half/PIX); off = (np.arange(n) - (n-1)/2) * PIX / 3600
    rows, cols = np.meshgrid(off, off, indexing="ij")   # row index -> north, col index -> west
    sra = ra - cols / np.cos(np.radians(dec))           # RA decreases left to right (east left)
    sde = dec + rows                                    # Dec increases upward (origin="lower")
    px, py = WCS(H).all_world2pix(sra, sde, 0)
    return map_coordinates(I, [py, px], order=1, mode="constant", cval=np.nan)

panels = []
for date, filt, ra0, dec0, snr in SEL:
    fr = frames(ra0, dec0, filt)
    s = [f for f in fr if f[0] == date][0]
    t0 = Time(date.replace(" ", "T"), scale="utc")
    tpl = sorted([f for f in fr if abs(Time(f[0].replace(" ", "T")).mjd - t0.mjd) >= 1.0],
                 key=lambda f: abs(Time(f[0].replace(" ", "T")).mjd - t0.mjd))[0]
    ra, dec = horizons([t0])[0]
    cuts = []
    for _, u in (s, tpl):
        I, H = load(u); cuts.append(north_up(I, H, ra, dec))
    dt = Time(tpl[0].replace(" ", "T")).mjd - t0.mjd
    panels.append((t0, filt, snr, dt, *cuts))

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10})
n = len(panels)
fig, axs = plt.subplots(2, n, figsize=(2.35*n + 0.6, 6.6), facecolor="white",
                        gridspec_kw=dict(hspace=0.32, wspace=0.06, left=0.03, right=0.995, top=0.85, bottom=0.06))
axs = np.atleast_2d(axs).reshape(2, n)
for k, (t0, filt, snr, dt, st, tt) in enumerate(panels):
    for row, im in ((0, st), (1, tt)):
        ax = axs[row, k]; _, md, sd = sigma_clipped_stats(im)
        ax.imshow(im, origin="lower", cmap="gray_r", vmin=md-1.5*sd, vmax=md+10*sd, interpolation="nearest")
        cx, cy = im.shape[1]/2, im.shape[0]/2; g, L = 1.6/PIX, 1.8/PIX   # open crosshair marker
        for dx, dy in ((1,0),(-1,0),(0,1),(0,-1)):
            ax.plot([cx+dx*g, cx+dx*(g+L)], [cy+dy*g, cy+dy*(g+L)], color="#d62728", lw=1.6)
        ax.set_xticks([]); ax.set_yticks([])
        for sp in ax.spines.values(): sp.set_color("#999")
    axs[0, k].set_title(f"{t0.datetime:%d %b %Y}\n{filt} band  ·  S/N {snr:.0f}", fontsize=10)
    when = f"{abs(dt):.0f} d {'later' if dt > 0 else 'earlier'}"
    axs[1, k].set_title(f"same sky, {when}", fontsize=9, color="#555")
axs[0, 0].set_ylabel("2026 ED138 present", fontsize=10)
axs[1, 0].set_ylabel("object gone", fontsize=10)
band = "Ks" if mode == "ks" else "Z/Y/J/H"
fig.suptitle(f"Precovery of distant TNO 2026 ED138 in VISTA/VVV {band} images", fontsize=13, fontweight="bold", y=0.985)
fig.text(0.5, 0.012,
         "Red marks: position predicted from the JPL orbit. Stamps 20″ × 20″, north up, east left.  "
         "Data: ESO VISTA VVV survey (VSA DR5). Orbit: JPL Horizons. Analysis: E. A. Puerto.",
         ha="center", fontsize=8, color="#444")
fig.savefig(OUT, dpi=200)
print("saved", OUT, n, "panels")
