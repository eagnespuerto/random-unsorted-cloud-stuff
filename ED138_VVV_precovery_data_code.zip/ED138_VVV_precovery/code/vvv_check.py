"""Forced difference photometry for 2026 ED138 in VVV pawprint stacks.

For each target night: fetch VSA 1' cutouts at the predicted position (all epochs, same
filter).  Frames from the target night = science; frames from other nights = templates
(object elsewhere).  Flux at the predicted RA/Dec (aperture, background annulus),
normalised by MAGZPT/EXPTIME, science minus template median.  Noise from the same
difference at random positions in the cutout.
"""
import re, sys, gzip, io, json, urllib.request, urllib.parse, numpy as np
from astropy.io import fits
from astropy.wcs import WCS
from astropy.stats import sigma_clipped_stats
from astropy.time import Time
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt

OUTDIR = sys.argv[1]; PNG = sys.argv[2]
FID = dict(Z=1, Y=2, J=3, H=4, Ks=5)
EXPECT = dict(Z=18.7, Y=18.5, J=18.1, H=17.6, Ks=17.2)   # Vega, from DECam grizY colours (rough)
NIGHTS = [  # (night, filter, ra, dec) from SSOIS
    ("2010-03-18", "J", 251.025608, -45.488050), ("2010-03-18", "H", 251.025644, -45.487962),
    ("2010-03-25", "J", 250.991663, -45.539027), ("2010-03-25", "H", 250.991726, -45.538961),
    ("2010-03-27", "J", 250.977224, -45.553060), ("2010-03-27", "H", 250.977305, -45.552989),
    ("2010-08-02", "Z", 248.377475, -45.320359), ("2010-08-02", "Y", 248.377529, -45.320404),
    ("2011-07-01", "Z", 250.567981, -45.569431), ("2011-07-01", "Y", 250.568097, -45.569463),
]
PIX = 0.339

def get(url, t=300): return urllib.request.urlopen(url, timeout=t).read()

def frames(ra, dec, filt):
    q = urllib.parse.urlencode(dict(archive="VSA", programmeID=120, database="VVVDR5", ra=ra, dec=dec, sys="J",
                                    filterID=FID[filt], xsize=1, ysize=1, obsType="object", frameType="stack", mfid="", fsid=""))
    html = get("http://vsa.roe.ac.uk:8080/vdfs/GetImage?" + q).decode("latin1")
    out = []
    for tr in re.split(r"<tr", html, flags=re.I)[1:]:   # VSA rows have no </tr>
        h = re.search(r'href="([^"]*getImage\.cgi[^"]*)"', tr)
        d = re.search(r"(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d)", tr)
        ft = re.search(r">\s*(stack|deepstack|tilestack|tiledeepstack)\s*<", tr)
        if h and d and ft and ft.group(1) == "stack":
            out.append((d.group(1), h.group(1).replace("&amp;", "&").replace("getImage.cgi", "getFImage.cgi")))
    return out

def horizons(times):
    tl = " ".join(f"'{t.jd:.6f}'" for t in times)
    q = urllib.parse.urlencode(dict(format="json", COMMAND="'2026 ED138;'", OBJ_DATA="NO", MAKE_EPHEM="YES",
                                    EPHEM_TYPE="OBSERVER", CENTER="'W91'", TLIST=tl, QUANTITIES="'1'",
                                    ANG_FORMAT="DEG", CSV_FORMAT="YES", EXTRA_PREC="YES"))
    txt = json.loads(get("https://ssd.jpl.nasa.gov/api/horizons.api?" + q))["result"]
    rows = txt.split("$$SOE")[1].split("$$EOE")[0].strip().splitlines()
    return [(float(r.split(",")[3]), float(r.split(",")[4])) for r in rows]

def load(url):
    raw = get(url)
    if raw[:2] == b"\x1f\x8b": raw = gzip.decompress(raw)
    h = fits.open(io.BytesIO(raw))
    hdu = next(x for x in h if x.data is not None)
    hdr = hdu.header.copy()
    for k in ("MAGZPT", "EXPTIME", "SEEING"):
        if k not in hdr and k in h[0].header: hdr[k] = h[0].header[k]
    return hdu.data.astype(float), hdr

def ap(img, x, y, r):
    yy, xx = np.indices(img.shape); rr = np.hypot(xx-x, yy-y)
    _, bk, _ = sigma_clipped_stats(img[(rr > 3*r) & (rr < 5*r)], sigma=2.5)
    return (img[rr < r] - bk).sum()

res, stamps = [], []
for night, filt, ra0, dec0 in NIGHTS:
    try: fr = frames(ra0, dec0, filt)
    except Exception as e: print(night, filt, "VSA error", e); continue
    sci = [f for f in fr if f[0].startswith(night)]
    tpl = [f for f in fr if not f[0].startswith(night)]
    if not sci or not tpl: print(night, filt, f"sci={len(sci)} tpl={len(tpl)} - skip"); continue
    t_sci = [Time(d.replace(" ", "T"), scale="utc") for d, _ in sci]
    pos = horizons(t_sci)
    T = [load(u) for _, u in tpl[:8]]
    rng = np.random.default_rng(0)
    for (d, u), (ra, dec) in zip(sci, pos):
        img, hdr = load(u); w = WCS(hdr)
        see = hdr.get("SEEING", 2.5)  # pixels in VSA headers
        r = max(1.0*see, 2.5)
        zp = hdr["MAGZPT"]; et = hdr["EXPTIME"]
        def norm(I, H, x, y): return ap(I, x, y, r) / H["EXPTIME"] * 10**(-0.4*(H["MAGZPT"]-25))
        def at(I, H, ra_, de_):
            x, y = (float(v) for v in WCS(H).all_world2pix(ra_, de_, 0)); return norm(I, H, x, y)
        def diff(ra_, de_):
            s = at(img, hdr, ra_, de_); tt = [at(I, H, ra_, de_) for I, H in T]; return s - np.median(tt)
        dval = diff(ra, dec)
        # random control positions (>6" from target, inside cutout)
        x0, y0 = (float(v) for v in w.all_world2pix(ra, dec, 0)); ctr = []
        H_, W_ = img.shape
        while len(ctr) < 60:
            x, y = rng.uniform(5*r, W_-5*r), rng.uniform(5*r, H_-5*r)
            if np.hypot(x-x0, y-y0) < 6/PIX: continue
            rr, dd = (float(v) for v in w.all_pix2world(x, y, 0)); ctr.append(diff(rr, dd))
        ctr = np.array(ctr); sig = 1.4826*np.median(np.abs(ctr-np.median(ctr)))
        expf = 10**(-0.4*(EXPECT[filt]-25)) * (1-2**(-4*(r/see)**2))   # aperture fraction ~ gaussian
        snr = (dval - np.median(ctr))/sig
        lim = 25 - 2.5*np.log10(5*sig/(1-2**(-4*(r/see)**2)))
        res.append((d, filt, see*PIX, snr, expf/sig, lim))
        print(f"{d} {filt} seeing {see*PIX:.2f}\"  SNR(diff) {snr:5.1f}   expected SNR {expf/sig:5.1f}   5sig lim {lim:5.2f}   ntpl {len(T)}")
        # stamp: science and first template, 20"
        hp = int(10/PIX); xi, yi = int(round(x0)), int(round(y0))
        st = img[max(yi-hp,0):yi+hp, max(xi-hp,0):xi+hp]
        I, H = T[0]; xt, yt = (float(v) for v in WCS(H).all_world2pix(ra, dec, 0)); xt, yt = int(round(xt)), int(round(yt))
        tt = I[max(yt-hp,0):yt+hp, max(xt-hp,0):xt+hp]
        stamps.append((f"{d[:10]} {filt}", st, tt, snr))

if stamps:
    sel = []
    seen = set()
    for s in stamps:   # one stamp per night+filter
        if s[0] not in seen: seen.add(s[0]); sel.append(s)
    n = len(sel)
    fig, axs = plt.subplots(2, n, figsize=(2.6*n, 5.8))
    axs = np.atleast_2d(axs).reshape(2, n)
    for k, (lab, st, tt, snr) in enumerate(sel):
        for row, im, ttl in ((0, st, f"{lab}\nSNR {snr:.1f}"), (1, tt, "other night")):
            ax = axs[row, k]; _, md, sd = sigma_clipped_stats(im)
            ax.imshow(im, origin="lower", cmap="gray_r", vmin=md-2*sd, vmax=md+8*sd)
            c = (im.shape[1]/2, im.shape[0]/2)
            ax.add_patch(plt.Circle(c, 1.5/PIX, fill=False, color="red"))
            ax.set_title(ttl, fontsize=9); ax.set_xticks([]); ax.set_yticks([])
    fig.suptitle("2026 ED138 in VVV: predicted position (red, r=1.5\"), 20\" stamps; bottom = same sky, other night")
    fig.tight_layout(h_pad=2); fig.savefig(PNG, dpi=110)
