"""Look for Gaia DR1/DR2/DR3 sources lying on the 2026 ED138 track, vs offset control tracks.

A mover can only show up as a fragmentary source: few transits, no parallax/PM
(2-parameter solution).  We pull faint sources in boxes along the track and count
those within R arcsec of the track, compared with the same track shifted N/S.
"""
import sys, io, csv, urllib.request, urllib.parse, numpy as np
exec(open("eph.py").read().split("if __name__")[0])
from astropy.time import Time

TAP = "https://gea.esac.esa.int/tap-server/tap/sync"
REL = {  # table, data window, mag column, extra filter
    "DR1": ("gaiadr1.gaia_source", "2014-07-25", "2015-09-16", "phot_g_mean_mag", "astrometric_n_good_obs_al > 0 AND parallax IS NULL"),
    "DR2": ("gaiadr2.gaia_source", "2014-07-25", "2016-05-23", "phot_g_mean_mag", "parallax IS NULL"),
    "DR3": ("gaiadr3.gaia_source", "2014-07-25", "2017-05-28", "phot_g_mean_mag", "astrometric_params_solved = 3"),
}
R = 2.0                      # match radius, arcsec
OFFS = [0, -40, 40, -80, 80]  # Dec shifts of track, arcsec (0 = real)

def tap(q):
    data = urllib.parse.urlencode(dict(REQUEST="doQuery", LANG="ADQL", FORMAT="csv", QUERY=q)).encode()
    txt = urllib.request.urlopen(TAP, data, timeout=600).read().decode()
    rows = list(csv.DictReader(io.StringIO(txt)))
    if rows and "ra" not in rows[0]: raise RuntimeError(txt[:500])
    return rows

t, ra, dec, *_ = load("eph/gaia6h.txt")
# dense track (every ~1") for distance computation
k = np.linspace(0, len(ra)-1, (len(ra)-1)*20+1)
tra = np.interp(k, np.arange(len(ra)), ra); tde = np.interp(k, np.arange(len(ra)), dec)
tjd = np.interp(k, np.arange(len(ra)), t.jd)

for rel, (tab, t0, t1, gcol, extra) in REL.items():
    m = (tjd >= Time(t0).jd) & (tjd <= Time(t1).jd)
    xr, xd = tra[m], tde[m]
    srcs = []
    n = len(xr); step = 1500     # ~1500 dense points ≈ 6 days ≈ 0.4 deg of track per box
    for i in range(0, n, step):
        sr, sd = xr[i:i+step+1], xd[i:i+step+1]
        pad = 130/3600
        q = (f"SELECT source_id, ra, dec, {gcol} AS g FROM {tab} WHERE "
             f"ra BETWEEN {sr.min()-pad/np.cos(np.radians(sd.mean())):.5f} AND {sr.max()+pad/np.cos(np.radians(sd.mean())):.5f} "
             f"AND dec BETWEEN {sd.min()-pad:.5f} AND {sd.max()+pad:.5f} "
             f"AND {gcol} BETWEEN 18.5 AND 21.5 AND {extra}")
        srcs += tap(q)
    ids = {}
    for s in srcs: ids[s["source_id"]] = (float(s["ra"]), float(s["dec"]), float(s["g"]))
    if not ids:
        print(f"{rel}: 0 candidate sources in boxes"); continue
    S = np.array(list(ids.values()))
    cosd = np.cos(np.radians(xd.mean()))
    out = []
    for off in OFFS:
        yd = xd + off/3600
        # nearest track point per source via sorting on RA would be faster; brute force in blocks
        hits = []
        for j, (sr_, sd_, g_) in enumerate(S):
            near = np.abs(xr - sr_) < 30/3600
            if not near.any(): continue
            dd = np.hypot((xr[near]-sr_)*cosd, yd[near]-sd_)*3600
            if dd.min() < R: hits.append(j)
        out.append(len(hits))
        if off == 0: real = [list(ids.keys())[j] + f" G={S[j,2]:.2f}" for j in hits]
    ctrl = np.array(out[1:])
    print(f"{rel}: {len(ids)} faint fragmentary sources in boxes; on real track (<{R}\"): {out[0]}; "
          f"control tracks: {ctrl.tolist()} (mean {ctrl.mean():.1f})")
    for r in real[:15]: print("   ", r)
