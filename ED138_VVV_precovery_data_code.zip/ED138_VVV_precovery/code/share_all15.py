"""All 15 VVV precovery frames of 2026 ED138, each over the same sky on another night.
Marker: JPL plane-of-sky uncertainty ellipse at the frame time, drawn as a band from 1-sigma to 3-sigma.
"""
import sys, json, urllib.request, urllib.parse, numpy as np
from astropy.time import Time
from astropy.wcs import WCS
from astropy.stats import sigma_clipped_stats
from scipy.ndimage import map_coordinates
from matplotlib.path import Path
from matplotlib.patches import PathPatch
exec("\n".join(l for l in open("vvv_check.py").read().split("res, stamps = []")[0].split("\n")
               if not l.startswith("OUTDIR")))
OUT = sys.argv[1]

SNR = {"2010-03-18 09:01:21.8": 8.3, "2010-03-18 09:03:34.1": 11.1, "2010-03-18 08:44:43.0": 7.6,
       "2010-03-18 08:46:50.1": 6.6, "2010-03-25 07:19:23.4": 7.8, "2010-03-25 07:20:25.3": 7.0,
       "2010-03-25 07:21:28.9": 8.4, "2010-08-02 04:40:59.3": 21.6, "2010-08-02 04:42:06.0": 13.0,
       "2010-08-02 04:33:39.6": 10.2, "2010-08-02 04:34:46.9": 11.7, "2011-07-01 03:53:23.8": 22.6,
       "2011-07-01 03:54:32.7": 30.5, "2011-07-01 03:46:00.7": 24.0, "2011-07-01 03:47:10.5": 21.5}

def north_up(I, H, ra, dec, half=10.0):
    n = int(2*half/PIX); off = (np.arange(n) - (n-1)/2) * PIX / 3600
    rows, cols = np.meshgrid(off, off, indexing="ij")
    px, py = WCS(H).all_world2pix(ra - cols/np.cos(np.radians(dec)), dec + rows, 0)
    return map_coordinates(I, [py, px], order=1, mode="constant", cval=np.nan)

def ellipses(times):
    tl = " ".join(f"'{t.jd:.6f}'" for t in times)
    q = urllib.parse.urlencode(dict(format="json", COMMAND="'2026 ED138;'", OBJ_DATA="NO", MAKE_EPHEM="YES",
                                    EPHEM_TYPE="OBSERVER", CENTER="'W91'", TLIST=tl, QUANTITIES="'1,37'",
                                    ANG_FORMAT="DEG", CSV_FORMAT="YES", EXTRA_PREC="YES"))
    txt = json.loads(urllib.request.urlopen("https://ssd.jpl.nasa.gov/api/horizons.api?" + q, timeout=120).read())["result"]
    out = []
    for r in txt.split("$$SOE")[1].split("$$EOE")[0].strip().splitlines():
        p = [x.strip() for x in r.split(",")]
        out.append((float(p[3]), float(p[4]), float(p[5]), float(p[6]), float(p[7])))
    return out   # ra, dec, a3 ("), b3 ("), theta (deg, from RA axis)

def band(cx, cy, a1, b1, a3, b3, ang):
    """Filled annulus between two concentric ellipses (pixel units, ang in deg ccw from +x)."""
    th = np.linspace(0, 2*np.pi, 200); c, s = np.cos(np.radians(ang)), np.sin(np.radians(ang))
    def ring(a, b):
        x, y = a*np.cos(th), b*np.sin(th); return np.c_[cx + c*x - s*y, cy + s*x + c*y]
    o, i = ring(a3, b3), ring(a1, b1)[::-1]
    v = np.r_[o, i]; codes = ([Path.MOVETO] + [Path.LINETO]*(len(o)-1)) * 2
    return PathPatch(Path(v, codes), fc=(0.84, 0.15, 0.16, 0.22), ec=(0.84, 0.15, 0.16, 0.95), lw=0.9)

SETS = [n for n in NIGHTS if not (n[0] == "2010-03-25" and n[1] == "H")]
panels = []
for night, filt, ra0, dec0 in SETS:
    fr = frames(ra0, dec0, filt)
    for _ in range(3):   # VSA occasionally returns an empty listing; retry
        if any(f[0].startswith(night) for f in fr): break
        fr = frames(ra0, dec0, filt)
    sci = sorted([f for f in fr if f[0].startswith(night)])
    tpl_all = [f for f in fr if not f[0].startswith(night)]
    print(night, filt, "sci", len(sci), "tpl", len(tpl_all), flush=True)
    if not sci: continue
    t_sci = [Time(d.replace(" ", "T"), scale="utc") for d, _ in sci]
    ells = ellipses(t_sci)
    for (d, u), t0, (ra, dec, a3, b3, th) in zip(sci, t_sci, ells):
        tpl = min(tpl_all, key=lambda f: abs(Time(f[0].replace(" ", "T")).mjd - t0.mjd))
        I, H = load(u); T, HT = load(tpl[1])
        dt = Time(tpl[0].replace(" ", "T")).mjd - t0.mjd
        panels.append((t0, filt, SNR.get(d, np.nan), dt, north_up(I, H, ra, dec), north_up(T, HT, ra, dec), a3, b3, th))
assert len(panels) == 15, len(panels)

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9})
NC = 5; NR = 3                                       # 3 bands of 5 pairs
fig, axs = plt.subplots(2*NR, NC, figsize=(2.3*NC + 0.4, 2.55*2*NR + 1.0), facecolor="white",
                        gridspec_kw=dict(hspace=0.30, wspace=0.05, left=0.045, right=0.995, top=0.915, bottom=0.04))
for k, (t0, filt, snr, dt, st, tt, a3, b3, th) in enumerate(panels):
    r, c = 2*(k // NC), k % NC
    for row, im in ((r, st), (r+1, tt)):
        ax = axs[row, c]; _, md, sd = sigma_clipped_stats(im)
        ax.imshow(im, origin="lower", cmap="gray_r", vmin=md-1.5*sd, vmax=md+10*sd, interpolation="nearest")
        cx, cy = (im.shape[1]-1)/2, (im.shape[0]-1)/2
        g, L = 1.6/PIX, 1.8/PIX   # open crosshair, same as the 7-panel figure
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            ax.plot([cx+dx*g, cx+dx*(g+L)], [cy+dy*g, cy+dy*(g+L)], color="#d62728", lw=1.6)
        ax.set_xticks([]); ax.set_yticks([])
        for sp in ax.spines.values(): sp.set_color("#999")
    axs[r, c].set_title(f"{t0.datetime:%d %b %Y %H:%M} UT\n{filt} band  ·  S/N {snr:.0f}", fontsize=9)
    axs[r+1, c].set_title(f"same sky, {abs(dt):.0f} d {'later' if dt > 0 else 'earlier'}", fontsize=8.5, color="#555")
    if c == 0:
        axs[r, c].set_ylabel("object present", fontsize=9); axs[r+1, c].set_ylabel("object gone", fontsize=9)
fig.suptitle("2026 ED138: all 15 VISTA/VVV precovery frames (2010–2011)", fontsize=14, fontweight="bold", y=0.985)
fig.text(0.5, 0.947, "Red marks: position predicted from the JPL orbit at each frame time.",
         ha="center", fontsize=9.5, color="#333")
fig.text(0.5, 0.012, "Stamps 20″ × 20″, north up, east left; each object frame is shown above the same sky from the nearest "
         "other night.  Data: ESO VISTA VVV (VSA DR5). Orbit: JPL Horizons. Analysis: E. A. Puerto.",
         ha="center", fontsize=8, color="#444")
fig.savefig(OUT, dpi=200)
print("saved", OUT)
