"""Parse the Horizons CSV into a numpy-friendly table + summary by year."""
import sys, numpy as np
from astropy.coordinates import SkyCoord
from astropy.time import Time
import astropy.units as u

def load(path):
    rows, on = [], False
    for ln in open(path):
        if ln.startswith("$$SOE"): on = True; continue
        if ln.startswith("$$EOE"): break
        if on:
            p = [x.strip() for x in ln.split(",")]
            rows.append((p[0], float(p[3]), float(p[4]), float(p[5]), float(p[7]), float(p[8]), float(p[9])))
    t = Time([r[0].replace("Jan","01").replace("Feb","02").replace("Mar","03").replace("Apr","04")
              .replace("May","05").replace("Jun","06").replace("Jul","07").replace("Aug","08")
              .replace("Sep","09").replace("Oct","10").replace("Nov","11").replace("Dec","12") for r in rows],
             format="iso", scale="utc")
    a = np.array([r[1:] for r in rows])
    return t, a[:,0], a[:,1], a[:,2], a[:,3], a[:,4], a[:,5]

if __name__ == "__main__":
    t, ra, dec, V, ura, udec, elong = load(sys.argv[1])
    g = SkyCoord(ra*u.deg, dec*u.deg).galactic
    yr = t.datetime64.astype("datetime64[Y]").astype(int) + 1970
    print("year  RA range        Dec range       l range        b range       V     3sig unc RA/Dec (\")")
    for y in np.unique(yr):
        m = yr == y
        print(f"{y}  {ra[m].min():6.2f}-{ra[m].max():6.2f}  {dec[m].min():6.2f}-{dec[m].max():6.2f}  "
              f"{g.l.deg[m].min():6.2f}-{g.l.deg[m].max():6.2f}  {g.b.deg[m].min():5.2f}-{g.b.deg[m].max():5.2f}  "
              f"{V[m].mean():5.2f}  {ura[m].max():5.2f}/{udec[m].max():4.2f}")
