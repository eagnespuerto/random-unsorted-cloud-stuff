"""Figure: 2026 ED138 sky track with all observations + O-C of the 15 VVV precovery positions."""
import sys, csv, numpy as np
exec(open("eph.py").read().split("if __name__")[0])
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import Circle

OUT = sys.argv[1]
INK, INK2, MUTED, GRID, SURF = "#0b0b0b", "#52514e", "#8a8984", "#e6e5e0", "#fcfcfb"
C_VVV, C_DEC, C_RUB = "#2a78d6", "#eb6834", "#1baf7a"   # categorical slots 1-3 (validated)

mpc = list(csv.DictReader(open("mpc_obs.csv")))
vvv = [r for r in csv.DictReader(open("vvv_astrometry.csv"))
       if not (r["date"].startswith("2010-03-25") and r["filt"] == "H")]
assert len(vvv) == 15

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.edgecolor": MUTED,
                     "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2})
fig = plt.figure(figsize=(13, 7.4), facecolor=SURF)
gs = fig.add_gridspec(1, 2, width_ratios=[1.25, 1], wspace=0.22, left=0.06, right=0.98, top=0.83, bottom=0.12)

# ---- panel A: the orbit, seen from above the ecliptic ----

from astropy.time import Time as _T

EL = dict(a=42.9486367, e=0.1417431, i=24.47104, node=322.50088, peri=167.95217,

          M0=128.33566, n=0.00350171, epoch=2461200.5)          # MPC / MPEC 2026-U85



def helio(E):

    """Heliocentric ecliptic x, y (au) for eccentric anomaly E (rad)."""

    a, e = EL["a"], EL["e"]

    xp, yp = a*(np.cos(E) - e), a*np.sqrt(1 - e*e)*np.sin(E)

    w, O, i = np.radians([EL["peri"], EL["node"], EL["i"]])

    x = (np.cos(O)*np.cos(w) - np.sin(O)*np.sin(w)*np.cos(i))*xp + (-np.cos(O)*np.sin(w) - np.sin(O)*np.cos(w)*np.cos(i))*yp

    y = (np.sin(O)*np.cos(w) + np.cos(O)*np.sin(w)*np.cos(i))*xp + (-np.sin(O)*np.sin(w) + np.cos(O)*np.cos(w)*np.cos(i))*yp

    return x, y



def at_jd(jd):

    M = np.radians(EL["M0"] + EL["n"]*(np.asarray(jd) - EL["epoch"]))

    E = M.copy()

    for _ in range(30): E = E - (E - EL["e"]*np.sin(E) - M)/(1 - EL["e"]*np.cos(E))

    return helio(E)



ax = fig.add_subplot(gs[0]); ax.set_facecolor(SURF)

ox, oy = helio(np.linspace(0, 2*np.pi, 721))

ax.plot(ox, oy, color="#9a9993", lw=1.6, zorder=2)

th = np.linspace(0, 2*np.pi, 361)

ax.plot(30.07*np.cos(th), 30.07*np.sin(th), color="#c9c8c2", lw=1, ls=(0, (4, 3)), zorder=1)

ax.text(0, 30.07, "Neptune's orbit", ha="center", va="center", fontsize=8.5, color=MUTED, zorder=3,

        bbox=dict(boxstyle="round,pad=0.15", fc=SURF, ec="none"))

ax.plot(0, 0, "o", ms=9, color="#eda100", mec=SURF, mew=1.5, zorder=4)

ax.annotate("Sun", (0, 0), xytext=(7, -2), textcoords="offset points", fontsize=9, color=INK2)

px, py = helio(np.array([0.0])); qx, qy = helio(np.array([np.pi]))

ax.plot(px, py, "|", ms=10, color=MUTED); ax.annotate("perihelion 36.9 au\n(1926)", (px[0], py[0]), xytext=(0, 9),

        textcoords="offset points", ha="center", fontsize=8, color=MUTED)

ax.annotate("aphelion 49.0 au", (qx[0], qy[0]), xytext=(0, -14), textcoords="offset points", ha="center",

            fontsize=8, color=MUTED)

ax.plot(qx, qy, "|", ms=10, color=MUTED)



def jd_mpc(s):

    y, m, d = s.split(); return _T(f"{y}-{m}-{int(float(d)):02d}").jd + float(d) % 1

groups = [("VVV / VISTA (W91)  2010–2011, 15 obs", C_VVV, "o", [_T(r["date"]).jd for r in vvv], 9, 6),

          ("DECam (W84)  2016–2023", C_DEC, "s", [jd_mpc(r["date"]) for r in mpc if r["stn"] == "W84"], 7, 5),

          ("Rubin (X05)  2026", C_RUB, "D", [jd_mpc(r["date"]) for r in mpc if r["stn"] == "X05"], 6.5, 5)]

for lab, c, m, jds, ms, z in groups:

    x, y = at_jd(np.array(jds))

    ax.plot(x, y, m, ms=ms, mfc=c, mec=SURF, mew=1.5, ls="none", label=lab, zorder=z)

# observed arc 2010-2026 drawn over the orbit

ax_, ay_ = at_jd(np.linspace(_T("2010-03-18").jd, _T("2026-07-11").jd, 200))

ax.plot(ax_, ay_, color=INK, lw=2.6, zorder=3, solid_capstyle="round")

mx, my = at_jd(np.array([_T("2018-06-01").jd]))

ax.annotate("observed arc\n2010–2026", (mx[0], my[0]), xytext=(-27, -22), ha="center",

            fontsize=9, color=INK, arrowprops=dict(arrowstyle="-", color=MUTED, lw=0.8),

            bbox=dict(boxstyle="round,pad=0.2", fc=SURF, ec="none"))

# direction of motion

d0x, d0y = at_jd(np.array([_T("2040-01-01").jd])); d1x, d1y = at_jd(np.array([_T("2048-01-01").jd]))

ax.annotate("", (d1x[0], d1y[0]), xytext=(d0x[0], d0y[0]),

            arrowprops=dict(arrowstyle="-|>", color=MUTED, lw=1.2, mutation_scale=12))

ax.set_aspect("equal"); L = 53; ax.set_xlim(-L, L); ax.set_ylim(-L, L)

ax.set_xlabel("x (au, ecliptic)"); ax.set_ylabel("y (au, ecliptic)")

ax.grid(color=GRID, lw=0.6); ax.set_axisbelow(True)

for s in ("top", "right"): ax.spines[s].set_visible(False)

ax.legend(loc="upper left", frameon=False, fontsize=8.5, handletextpad=0.4, labelcolor=INK2,

          bbox_to_anchor=(-0.02, 1.0))

ax.set_title("Orbit seen from above the ecliptic, with all reported positions", loc="left", fontsize=11,

             color=INK, pad=8)



# ---- panel B: O-C of the 15 VVV positions ----
bx = fig.add_subplot(gs[1]); bx.set_facecolor(SURF)
nights = sorted({r["date"][:10] for r in vvv})
nm = dict(zip(nights, ["o", "s", "^", "D"]))
for n in nights:
    rs = [r for r in vvv if r["date"].startswith(n)]
    x = [float(r["omc_ra"]) for r in rs]; y = [float(r["omc_dec"]) for r in rs]
    bx.plot(x, y, nm[n], ms=8, mfc=C_VVV, mec=SURF, mew=1.5, ls="none",
            label=f"{n}  ({', '.join(sorted({r['filt'] for r in rs}))}, {len(rs)})", zorder=3)
for rr in (0.1, 0.2):
    bx.add_patch(Circle((0, 0), rr, fill=False, ls="--", lw=0.8, ec=MUTED, zorder=1))
    bx.annotate(f"{rr:.1f}″", (rr*0.71, rr*0.71), xytext=(3, 3), textcoords="offset points",
                fontsize=8, color=MUTED)
bx.axhline(0, color=GRID, lw=0.8, zorder=0); bx.axvline(0, color=GRID, lw=0.8, zorder=0)
lim = 0.25; bx.set_xlim(lim, -lim); bx.set_ylim(-lim, lim); bx.set_aspect("equal")
bx.set_xlabel("ΔRA·cos δ, observed − JPL (″)"); bx.set_ylabel("ΔDec (″)")
for s in ("top", "right"): bx.spines[s].set_visible(False)
ora = np.array([float(r["omc_ra"]) for r in vvv]); ode = np.array([float(r["omc_dec"]) for r in vvv])
bx.text(0.5, -0.30, f"rms {np.sqrt(np.mean(ora**2)):.2f}″ in RA, {np.sqrt(np.mean(ode**2)):.2f}″ in Dec",
        transform=bx.transAxes, ha="center", fontsize=9, color=INK2)
bx.legend(loc="lower left", frameon=False, fontsize=8, title="night (bands, n)", title_fontsize=8,
          labelcolor=INK2, handletextpad=0.3, borderaxespad=0.2)
bx.set_title("The 15 VVV positions vs the JPL orbit", loc="left", fontsize=11, color=INK, pad=8)

fig.suptitle("2026 ED138: VISTA/VVV precovery extends the observed arc from 2016 back to 2010",
             x=0.06, ha="left", fontsize=14, fontweight="bold", color=INK, y=0.97)
fig.text(0.06, 0.905, "Distant TNO, a ≈ 42.9 au, H = 2.93. VVV positions submitted to the MPC 2026-10-28 "
         "(pending acceptance). Orbit uncertainty is far thinner than the line drawn.", fontsize=9.5, color=INK2)
fig.text(0.06, 0.025, "Data: ESO VISTA VVV survey via VSA DR5; MPC observations database (MPEC 2026-U85); "
         "JPL Horizons. Analysis: E. A. Puerto.", fontsize=8, color=MUTED)
fig.savefig(OUT, dpi=200, facecolor=SURF)
print("saved", OUT)
