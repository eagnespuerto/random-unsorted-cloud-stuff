"""Look for 2026 ED138 at CATCH-predicted positions in SkyMapper cutouts."""
import sys, numpy as np
from astropy.io import fits
from astropy.wcs import WCS
from astropy.stats import sigma_clipped_stats
from scipy.ndimage import gaussian_filter
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

D = sys.argv[1]; OUT = sys.argv[2]
# id, filter, seeing("), predicted RA, Dec (CATCH, JPL orbit)
F = [("20190506140615-30","i",2.91,264.59913,-44.69032),
     ("20190506140815-30","z",2.88,264.59910,-44.69032),
     ("20190507142721-20","g",3.42,264.57998,-44.69421),
     ("20190507142921-20","r",3.29,264.57995,-44.69422),
     ("20190805103702-32","i",1.94,262.54539,-44.51840),
     ("20190805103902-32","z",2.13,262.54537,-44.51839),
     ("20190815123956-10","i",3.28,262.41546,-44.44457),
     ("20190815124159-10","z",3.41,262.41545,-44.44456),
     ("20200529134409-28","g",3.01,265.60033,-44.53842),
     ("20200529134610-28","r",2.83,265.60029,-44.53843)]
# control: same sky spot on the other night (a star stays, a mover is gone)
CTRL = {"20190506140615-30":(264.57998,-44.69421),"20190506140815-30":(264.57998,-44.69421),
        "20190507142721-20":(264.59913,-44.69032),"20190507142921-20":(264.59913,-44.69032)}
PIX = 0.497
rng = np.random.default_rng(1)

def phot(img, x, y, r, rin, rout):
    yy, xx = np.indices(img.shape)
    rr = np.hypot(xx - x, yy - y)
    ann = img[(rr >= rin) & (rr < rout)]
    _, bk, _ = sigma_clipped_stats(ann, sigma=2.5)
    ap = rr < r
    return (img[ap] - bk).sum(), ap.sum()

def measure(img, wcs, ra, dec, fwhm_px, search_px):
    x0, y0 = (float(v) for v in wcs.all_world2pix(ra, dec, 0))
    sm = gaussian_filter(img, fwhm_px / 2.355)
    ys, xs = int(round(y0)), int(round(x0)); s = int(np.ceil(search_px))
    box = sm[ys-s:ys+s+1, xs-s:xs+s+1]
    yy, xx = np.indices(box.shape)
    m = np.hypot(xx - s, yy - s) <= search_px
    k = np.argmax(np.where(m, box, -np.inf))
    py, px = np.unravel_index(k, box.shape); px += xs - s; py += ys - s
    r = 0.8 * fwhm_px
    f, n = phot(img, px, py, r, 3*fwhm_px, 5*fwhm_px)
    # empirical noise: same peak-search on random positions (accounts for crowding & search bias)
    rf = []
    H, W = img.shape; mrg = int(6*fwhm_px) + s
    for _ in range(300):
        rx, ry = rng.uniform(mrg, W-mrg), rng.uniform(mrg, H-mrg)
        f0, _ = phot(img, rx, ry, r, 3*fwhm_px, 5*fwhm_px); rf.append(f0)
    rf = np.array(rf); med = np.median(rf); mad = 1.4826*np.median(np.abs(rf - med))
    return dict(x0=float(x0), y0=float(y0), px=int(px), py=int(py),
                off=float(np.hypot(px-x0, py-y0)*PIX), flux=float(f), snr=float((f-med)/mad),
                pct=float((rf < f).mean()*100))

rows = []
F = [f for f in F if not f[0].startswith("20190815")]  # object falls off these cutouts
fig, axs = plt.subplots(2, 4, figsize=(13, 7))
for ax, (pid, filt, see, ra, dec) in zip(axs.flat, F):
    with fits.open(f"{D}/{pid}.fits") as h:
        img = h[0].data.astype(float); hdr = h[0].header
    wcs = WCS(hdr); fw = see / PIX
    zp = next((hdr[k] for k in ("ZPAPPROX","ZP","MAGZP","PHOTZP") if k in hdr), None)
    m = measure(img, wcs, ra, dec, fw, 2.0/PIX)
    c = measure(img, wcs, *CTRL[pid], fw, 2.0/PIX) if pid in CTRL else None
    rows.append((pid, filt, see, m, c, zp))
    half = int(15/PIX); x0, y0 = int(round(m["x0"])), int(round(m["y0"]))
    st = img[y0-half:y0+half, x0-half:x0+half]
    _, md, sd = sigma_clipped_stats(st)
    ax.imshow(st, origin="lower", cmap="gray_r", vmin=md-2*sd, vmax=md+6*sd)
    ax.add_patch(plt.Circle((m["x0"]-x0+half, m["y0"]-y0+half), 2.0/PIX, fill=False, color="red"))
    ax.set_title(f"{pid[:8]} {filt}  seeing {see:.1f}\"\nSNR {m['snr']:.1f}  off {m['off']:.1f}\"", fontsize=9)
    ax.set_xticks([]); ax.set_yticks([])
fig.suptitle("2026 ED138 in SkyMapper DR4, 30\" stamps, red = predicted position (r = 2\")")
fig.tight_layout(h_pad=2.5); fig.savefig(OUT, dpi=110)

print(f"{'frame':18} f  see  SNR   pctl  off\"  | control(other night) SNR")
for pid, filt, see, m, c, zp in rows:
    cs = f"{c['snr']:.1f}" if c else "-"
    print(f"{pid:18} {filt} {see:4.1f} {m['snr']:5.1f} {m['pct']:5.0f} {m['off']:5.2f} | {cs}   zp={zp}")
