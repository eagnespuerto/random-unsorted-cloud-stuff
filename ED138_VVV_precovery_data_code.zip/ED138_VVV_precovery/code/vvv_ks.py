"""Forced difference photometry of 2026 ED138 in VVV Ks pawprint stacks, 2010-2014.

Science = stacks within 0.3 d of the SSOIS epoch; templates = stacks >= 1 d away
(object then >30" off).  Same method as vvv_check.py.  Writes ks_results.csv.
"""
import sys, csv, numpy as np
from astropy.time import Time
from astropy.wcs import WCS
exec("\n".join(l for l in open("vvv_check.py").read().split("res, stamps = []")[0].split("\n")
               if not l.startswith("OUTDIR")))

nights = [l.split() for l in open("ks_nights.txt")]
out = open("ks_results.csv", "w", newline=""); wr = csv.writer(out)
wr.writerow(["date", "mjd", "seeing", "snr", "exp_snr", "lim5", "ntpl"])
rng = np.random.default_rng(0)
for mjd0, ra0, dec0, tile, nexp in nights:
    mjd0 = float(mjd0)
    try: fr = frames(float(ra0), float(dec0), "Ks")
    except Exception as e: print(mjd0, "VSA error", e, flush=True); continue
    mj = [Time(d.replace(" ", "T"), scale="utc").mjd for d, _ in fr]
    sci = [f for f, m in zip(fr, mj) if abs(m - mjd0) < 0.3]
    tpl = [f for f, m in zip(fr, mj) if abs(m - mjd0) >= 1.0]
    if not sci or len(tpl) < 2: print(mjd0, f"sci={len(sci)} tpl={len(tpl)} skip", flush=True); continue
    # templates: closest-in-time 8 (similar conditions/epoch of variable stars)
    tpl = sorted(tpl, key=lambda f: abs(Time(f[0].replace(" ", "T")).mjd - mjd0))[:8]
    try:
        T = [load(u) for _, u in tpl]
        pos = horizons([Time(d.replace(" ", "T"), scale="utc") for d, _ in sci])
    except Exception as e: print(mjd0, "load error", e, flush=True); continue
    for (d, u), (ra, dec) in zip(sci, pos):
        try: img, hdr = load(u)
        except Exception as e: print(d, "load error", e, flush=True); continue
        w = WCS(hdr); see = hdr.get("SEEING", 2.5); r = max(1.0*see, 2.5)
        def at(I, H, ra_, de_):
            x, y = (float(v) for v in WCS(H).all_world2pix(ra_, de_, 0))
            if not (5*r < x < I.shape[1]-5*r and 5*r < y < I.shape[0]-5*r): return np.nan
            return ap(I, x, y, r) / H["EXPTIME"] * 10**(-0.4*(H["MAGZPT"]-25))
        def diff(ra_, de_):
            s = at(img, hdr, ra_, de_); tt = [at(I, H, ra_, de_) for I, H in T]
            return s - np.nanmedian(tt)
        dval = diff(ra, dec)
        if not np.isfinite(dval): print(d, "off cutout", flush=True); continue
        x0, y0 = (float(v) for v in w.all_world2pix(ra, dec, 0)); ctr = []
        H_, W_ = img.shape; tries = 0
        while len(ctr) < 60 and tries < 400:
            tries += 1
            x, y = rng.uniform(5*r, W_-5*r), rng.uniform(5*r, H_-5*r)
            if np.hypot(x-x0, y-y0) < 6/PIX: continue
            rr, dd = (float(v) for v in w.all_pix2world(x, y, 0)); v = diff(rr, dd)
            if np.isfinite(v): ctr.append(v)
        ctr = np.array(ctr); sig = 1.4826*np.median(np.abs(ctr-np.median(ctr)))
        apf = 1-2**(-4*(r/see)**2)
        expf = 10**(-0.4*(EXPECT["Ks"]-25))*apf
        snr = (dval-np.median(ctr))/sig; lim = 25-2.5*np.log10(5*sig/apf)
        tm = Time(d.replace(" ", "T"), scale="utc")
        wr.writerow([d, f"{tm.mjd:.6f}", f"{see*PIX:.2f}", f"{snr:.2f}", f"{expf/sig:.2f}", f"{lim:.2f}", len(T)]); out.flush()
        print(f"{d} Ks seeing {see*PIX:.2f}\" SNR {snr:5.1f} expected {expf/sig:4.1f} lim {lim:5.2f}", flush=True)
out.close()
