"""Upload the 2026 ED138 note to Zenodo (REST API quickstart flow).

  python zenodo_upload.py create            -> new DRAFT deposition, files uploaded, metadata set
  python zenodo_upload.py publish <dep_id>  -> publish that draft (permanent, mints a DOI)

Token: environment variable ZENODO_TOKEN (scopes deposit:write, deposit:actions). Never printed.
"""
import json, os, sys, pathlib, urllib.request, urllib.error

API = "https://zenodo.org/api"
HERE = pathlib.Path(__file__).parent
FILES = ["Puerto_2026_ED138_VVV_precovery.pdf", "ED138_VVV_precovery_data_code.zip",
         "ed138_W91_precovery_ades.psv"]

def token():
    t = os.environ.get("ZENODO_TOKEN")
    if not t: sys.exit("ZENODO_TOKEN is not set.")
    return t

def call(method, url, body=None, ctype="application/json"):
    data = body if isinstance(body, (bytes, type(None))) else json.dumps(body).encode()
    req = urllib.request.Request(url, data=data, method=method,
                                 headers={"Authorization": f"Bearer {token()}", "Content-Type": ctype})
    try:
        with urllib.request.urlopen(req, timeout=600) as r:
            raw = r.read(); return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        sys.exit(f"{method} {url.split('?')[0]} -> HTTP {e.code}: {e.read().decode()[:800]}")

def create():
    dep = call("POST", f"{API}/deposit/depositions", {})
    bucket = dep["links"]["bucket"]
    for name in FILES:
        r = call("PUT", f"{bucket}/{name}", (HERE / name).read_bytes(), "application/octet-stream")
        print(f"uploaded {name}  {r.get('size')} bytes  md5 {r.get('checksum')}")
    meta = json.loads((HERE / "zenodo_metadata.json").read_text(encoding="utf-8"))
    dep = call("PUT", f"{API}/deposit/depositions/{dep['id']}", meta)
    print("deposition id:", dep["id"])
    print("reserved DOI :", dep["metadata"].get("prereserve_doi", {}).get("doi"))
    print("draft page   :", dep["links"]["html"])
    print("state        :", dep["state"], "| submitted:", dep["submitted"])

def update(dep_id):
    """Replace the files and metadata of an unpublished draft."""
    dep = call("GET", f"{API}/deposit/depositions/{dep_id}")
    if dep["submitted"]: sys.exit("Already published; make a new version instead.")
    for f in call("GET", f"{API}/deposit/depositions/{dep_id}/files"):
        call("DELETE", f"{API}/deposit/depositions/{dep_id}/files/{f['id']}")
    for name in FILES:
        r = call("PUT", f"{dep['links']['bucket']}/{name}", (HERE / name).read_bytes(), "application/octet-stream")
        print(f"uploaded {name}  {r.get('size')} bytes  md5 {r.get('checksum')}")
    meta = json.loads((HERE / "zenodo_metadata.json").read_text(encoding="utf-8"))
    dep = call("PUT", f"{API}/deposit/depositions/{dep_id}", meta)
    print("title:", dep["metadata"]["title"]); print("state:", dep["state"], "| submitted:", dep["submitted"])

def publish(dep_id):
    dep = call("POST", f"{API}/deposit/depositions/{dep_id}/actions/publish")
    print("published   :", dep["state"], dep["submitted"])
    print("DOI         :", dep.get("doi"))
    print("concept DOI :", dep.get("conceptdoi"))
    print("record      :", dep["links"].get("record_html") or dep["links"].get("html"))

if __name__ == "__main__":
    if sys.argv[1:2] == ["create"]: create()
    elif sys.argv[1:2] == ["update"] and len(sys.argv) == 3: update(sys.argv[2])
    elif sys.argv[1:2] == ["publish"] and len(sys.argv) == 3: publish(sys.argv[2])
    else: sys.exit(__doc__)
