"""Astrometry of 2026 ED138 in VVV pawprint stacks, tied to Gaia DR3.

Per science frame:
  1. median of other-night templates resampled onto the science grid, flux-scaled, subtracted
  2. 2-D Gaussian fit to the residual near the JPL prediction -> object pixel position
  3. Gaia DR3 stars (G 13-19, propagated to epoch) fitted in the science image -> median
     sky offset of the VSA WCS; applied to the object
Writes a CSV of results and an ADES PSV draft.
"""
import sys, io, csv, json, urllib.request, urllib.parse, numpy as np
from astropy.io import fits
from astropy.wcs import WCS
from astropy.time import Time
from astropy.stats import sigma_clipped_stats
from scipy.ndimage import map_coordinates
from scipy.optimize import curve_fit
sys.path.insert(0, ".")
exec("\n".join(l for l in open("vvv_check.py").read().split("res, stamps = []")[0].split("\n")
               if not l.startswith("OUTDIR")))
OUTCSV, OUTPSV = sys.argv[1], sys.argv[2]

def gauss(xy, a, x0, y0, s, b):
    x, y = xy; return (a*np.exp(-((x-x0)**2+(y-y0)**2)/(2*s*s)) + b).ravel()

def fit(img, x, y, s0, half=None):
    half = half or int(max(3, 2.5*s0)); xi, yi = int(round(x)), int(round(y))
    sub = img[yi-half:yi+half+1, xi-half:xi+half+1]
    if sub.shape != (2*half+1, 2*half+1) or not np.isfinite(sub).all(): return None
    yy, xx = np.mgrid[yi-half:yi+half+1, xi-half:xi+half+1]
    p0 = [sub.max()-np.median(sub), x, y, s0, np.median(sub)]
    try:
        p, C = curve_fit(gauss, (xx, yy), sub.ravel(), p0=p0, maxfev=4000)
    except Exception: return None
    if p[0] <= 0 or not (0.5*s0 < abs(p[3]) < 2.5*s0) or np.hypot(p[1]-x, p[2]-y) > half: return None
    e = np.sqrt(np.diag(C))
    return p[1], p[2], e[1], e[2], p[0]

def gaia(ra, dec, rad_deg, epoch):
    q = (f"SELECT ra, dec, pmra, pmdec, phot_g_mean_mag FROM gaiadr3.gaia_source WHERE "
         f"1=CONTAINS(POINT('ICRS',ra,dec),CIRCLE('ICRS',{ra},{dec},{rad_deg})) AND phot_g_mean_mag BETWEEN 13 AND 19 "
         f"AND ruwe < 1.4")
    data = urllib.parse.urlencode(dict(REQUEST="doQuery", LANG="ADQL", FORMAT="csv", QUERY=q)).encode()
    rows = list(csv.DictReader(io.StringIO(urllib.request.urlopen("https://gea.esac.esa.int/tap-server/tap/sync", data, timeout=300).read().decode())))
    dt = epoch - 2016.0; out = []
    for r in rows:
        pa = float(r["pmra"] or 0); pd = float(r["pmdec"] or 0); d = float(r["dec"])
        out.append((float(r["ra"]) + pa*dt/3.6e6/np.cos(np.radians(d)), d + pd*dt/3.6e6))
    return np.array(out)

results = []
for night, filt, ra0, dec0 in NIGHTS:
    fr = frames(ra0, dec0, filt)
    sci = [f for f in fr if f[0].startswith(night)]; tpl = [f for f in fr if not f[0].startswith(night)]
    if not sci or not tpl: continue
    T = [load(u) for _, u in tpl[:8]]
    for d, u in sci:
        img, hdr = load(u); w = WCS(hdr)
        tmid = Time(hdr.get("ESO DET EXP UTC", hdr["DATE-OBS"]), scale="utc")
        ra_p, dec_p = horizons([tmid])[0]
        fs = 10**(-0.4*(hdr["MAGZPT"]-25))/hdr["EXPTIME"]
        yy, xx = np.indices(img.shape); sra, sde = w.all_pix2world(xx, yy, 0)
        rs = []
        for I, H in T:
            tx, ty = WCS(H).all_world2pix(sra, sde, 0)
            R = map_coordinates(I, [ty, tx], order=3, mode="constant", cval=np.nan)
            ft = 10**(-0.4*(H["MAGZPT"]-25))/H["EXPTIME"]
            _, bt, _ = sigma_clipped_stats(R[np.isfinite(R)])
            rs.append((R - bt)*ft/fs)
        _, bs, _ = sigma_clipped_stats(img)
        diff = (img - bs) - np.nanmedian(rs, axis=0)
        s0 = hdr["SEEING"]/2.355
        xp, yp = (float(v) for v in w.all_world2pix(ra_p, dec_p, 0))
        o = fit(diff, xp, yp, s0)
        if o is None: print(d, filt, "object fit failed"); continue
        xo, yo, exo, eyo, amp = o
        # Gaia tie
        G = gaia(ra_p, dec_p, 0.45/60*1.4, tmid.decimalyear)
        dra, dde = [], []
        for gr, gd in G:
            gx, gy = (float(v) for v in w.all_world2pix(gr, gd, 0))
            if not (8 < gx < img.shape[1]-8 and 8 < gy < img.shape[0]-8): continue
            f_ = fit(img - bs, gx, gy, s0)
            if f_ is None: continue
            mr, md = (float(v) for v in w.all_pix2world(f_[0], f_[1], 0))
            dra.append((mr-gr)*np.cos(np.radians(gd))*3600); dde.append((md-gd)*3600)
        dra, dde = np.array(dra), np.array(dde)
        _, mra, sra_ = sigma_clipped_stats(dra, sigma=2.5); _, mde, sde_ = sigma_clipped_stats(dde, sigma=2.5)
        n = len(dra)
        ro, do = (float(v) for v in w.all_pix2world(xo, yo, 0))
        ra_c = ro - mra/3600/np.cos(np.radians(do)); de_c = do - mde/3600
        sig_ra = np.hypot(exo*PIX, sra_/np.sqrt(max(n,1))); sig_de = np.hypot(eyo*PIX, sde_/np.sqrt(max(n,1)))
        omc_ra = (ra_c-ra_p)*np.cos(np.radians(de_c))*3600; omc_de = (de_c-dec_p)*3600
        results.append(dict(date=tmid.isot, filt=filt, ra=ra_c, dec=de_c, sig_ra=sig_ra, sig_dec=sig_de,
                            omc_ra=omc_ra, omc_dec=omc_de, ngaia=n, wcs_off_ra=mra, wcs_off_dec=mde,
                            seeing=hdr["SEEING"]*PIX))
        print(f"{tmid.isot[:19]} {filt}  RA {ra_c:.6f} Dec {de_c:.6f}  sig {sig_ra:.3f}/{sig_de:.3f}\"  "
              f"O-C {omc_ra:+.2f} {omc_de:+.2f}\"  Gaia N={n} WCS offset {mra:+.3f} {mde:+.3f}")

with open(OUTCSV, "w", newline="") as f:
    wr = csv.DictWriter(f, fieldnames=list(results[0].keys())); wr.writeheader(); wr.writerows(results)

def sexa(ra, dec):
    return f"{ra:.7f}", f"{dec:+.7f}"
hdr_lines = """# version=2017
# observatory
! mpcCode W91
# submitter
! name E. A. Puerto
! institution Independent researcher
# observers
! name VVV Survey Team
# measurers
! name E. A. Puerto
# telescope
! design Reflector
! aperture 4.1
! detector CCD
# comment
! line DRAFT - not submitted. Precovery measurements from VVV (ESO 179.B-2002) pawprint stacks via VSA DR5.
! line Template-subtracted Gaussian centroids; WCS re-tied locally to Gaia DR3 (G 13-19).
! line Detector is a HgCdTe IR array; 'CCD' used as ADES mode. Mid-times from detector EXP UTC (+-10 s).
"""
cols = ["permID","provID","trkSub","mode","stn","obsTime","ra","dec","rmsRA","rmsDec","astCat","band","remarks"]
with open(OUTPSV, "w") as f:
    f.write(hdr_lines)
    f.write("|".join(cols) + "\n")
    for r in results:
        ra, de = sexa(r["ra"], r["dec"])
        f.write("|".join(["", "2026 ED138", "", "CCD", "W91", r["date"][:22]+"Z", ra, de,
                          f"{max(r['sig_ra'],0.05):.3f}", f"{max(r['sig_dec'],0.05):.3f}", "Gaia3", r["filt"],
                          f"VVV precovery O-C {r['omc_ra']:+.2f} {r['omc_dec']:+.2f}"]) + "\n")
print("wrote", OUTCSV, OUTPSV, len(results), "rows")
